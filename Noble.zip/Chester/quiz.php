<!DOCTYPE html>
<html lang="en">
<head>
    <form action="answer.php" method="post">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <link rel= "stylesheet" href="styles.css">
</head>
<body class="container">


<h3 class="con1">Quiz<h3>

    <div class="con2">
    <h2>1.What is the capital of france?</h2>
    <label><input type="radio" value="A" name="answer_1" id="" required>A. London</label><br>
    <label><input type="radio" value="B" name="answer_1" id="" required>B. Berlin</label><br>
    <label><input type="radio" value="C" name="answer_1" id="" required>C. Paris</label><br>
    <label><input type="radio" value="D" name="answer_1" id="" required>D. Rome</label>
    </div>

    <div class="con2">
    <h2>2.What is the chemical symbol for gold?</h2>
    <label><input type="radio" value="A" name="answer_2" id="" required>A. Go</label> <br>
    <label><input type="radio" value="B" name="answer_2" id="" required>B. Gi</label><br>
    <label><input type="radio" value="C" name="answer_2" id="" required>C. Gd</label><br>
    <label><input type="radio" value="D" name="answer_2" id="" required>D. Au</label>
    </div>

    <div class="con2">    
    <h2>3. Which planet is known as the "Red planet"?</h2>
    <label><input type="radio" value="A" name="answer_3" id="" required>A. Venus</label><br>
    <label><input type="radio" value="B" name="answer_3" id="" required>B. Jupiter</label><br>
    <label><input type="radio" value="C" name="answer_3" id="" required>C. Mars</label><br>
    <label><input type="radio" value="D" name="answer_3" id="" required>D. Saturn</label>
    </div>

    <div class="con2">
    <h2>4. Who wrote the play "Romeo and Juliet"?</h2>
    <label><input type="radio" value="A" name="answer_4" id="" required>A. Charles Dickens</label><br>
    <label><input type="radio" value="B" name="answer_4" id="" required>B. William Shakespeare</label><br>
    <label><input type="radio" value="C" name="answer_4" id="" required>C. Mark Twain</label><br>
    <label><input type="radio" value="D" name="answer_4" id="" required>D. Jane Austen</label>
    </div>

  

    <div class="con2">
    <h2>5. What is the largest mammal on Earth?</h2>
    <label><input type="radio" value="A" name="answer_5" id="" required>A. Elephant</label><br>
    <label><input type="radio" value="B" name="answer_5" id="" required>B. Blue Whale</label><br>
    <label><input type="radio" value="C" name="answer_5" id="" required>C. Giraffe</label><br>
    <label><input type="radio" value="D" name="answer_5" id="" required>D. Polar Bear</label>
    </div>

    <div class="con2">
    <h2>6. In which year did Christopher Columbus discover America?</h2>
    <label><input type="radio" value="A" name="answer_6" id="" required>A. 1492</label><br>
    <label><input type="radio" value="B" name="answer_6" id="" required>B. 1776</label><br>
    <label><input type="radio" value="C" name="answer_6" id="" required>C. 1620</label><br>
    <label><input type="radio" value="D" name="answer_6" id="" required>D. 1517</label>
    </div>

    <div class="con2">
    <h2>7. What is the powerhouse of cell?</h2><br>
    <label><input type="radio" value="A" name="answer_7" id="" required>A. Ribosome</label><br>
    <label><input type="radio" value="B" name="answer_7" id="" required>B. Nucleus</label><br>
    <label><input type="radio" value="C" name="answer_7" id="" required>C. Mitochondria</label><br>
    <label><input type="radio" value="D" name="answer_7" id="" required>D. Golgi Apparatus</label>
    </div>

    <div class="con2">
    <h2>8. Who painted the Mona Lisa?</h2>
    <label><input type="radio" value="A" name="answer_8" id="" required>A. Vincent van Gogh</label><br>
    <label><input type="radio" value="B" name="answer_8" id="" required>B. Pablo Picasso</label><br>
    <label><input type="radio" value="C" name="answer_8" id="" required>C. Leonardo the Vinci</label><br>
    <label><input type="radio" value="D" name="answer_8" id="" required>D. Michelangelo</label>
    </div>

    
    <div class="con2">
    <h2>9. What is the chemical formula for water?</h2>
    <label><input type="radio" value="A" name="answer_9" id="" required>A. H20</label><br>
    <label><input type="radio" value="B" name="answer_9" id="" required>B. CO2</label><br>
    <label><input type="radio" value="C" name="answer_9" id="" required>C. O2</label><br>
    <label><input type="radio" value="D" name="answer_9" id="" required>D. NaCI</label>
    </div>

    <div class="con2">
    <h2>10. Which gas makes up the majority of Earth's atmosphere?</h2>
    <label><input type="radio" value="A" name="answer_10" id="" required>A. Oxygen</label><br>
    <label><input type="radio" value="B" name="answer_10" id="" required>B. Carbon dioxide</label><br>
    <label><input type="radio" value="C" name="answer_10" id="" required>C. Nitrogen</label><br>
    <label><input type="radio" value="D" name="answer_10" id="" required>D. Hydrogen</label>
    </div>

    <div class="con2">
    <h2>11. What is the largest organ in the human body?</h2>
    <label><input type="radio" value="A" name="answer_11" id="" required>A. Liver</label><br>
    <label><input type="radio" value="B" name="answer_11" id="" required>B. Skin</label><br>
    <label><input type="radio" value="C" name="answer_11" id="" required>C. Heart</label><br>
    <label><input type="radio" value="D" name="answer_11" id="" required>D. Brain</label>
    </div>

    <div class="con2">
    <h2>12.Which of these is primary color?</h2>
    <label><input type="radio" value="A" name="answer_12" id="" required>A. Purple</label><br>
    <label><input type="radio" value="B" name="answer_12" id="" required>B. Green</label><br>
    <label><input type="radio" value="C" name="answer_12" id="" required>C. Orange</label><br>
    <label><input type="radio" value="D" name="answer_12" id="" required>D. Blue</label>
    </div>

    

    <div class="con2">
    <h2>13. Who is the author of "To kill a mockingbird"?</h2>
    <label><input type="radio" value="A" name="answer_13" id="" required>A. F.Scott Fitzgerald</label><br>
    <label><input type="radio" value="B" name="answer_13" id="" required>B. J.K. Rowling</label><br>
    <label><input type="radio" value="C" name="answer_13" id="" required>C. Harper Lee</label><br>
    <label><input type="radio" value="D" name="answer_13" id="" required>D. George Orwell</label>
    </div>
    
    <div class="con2">
    <h2>14. What is the currency of Japan?</h2>
    <label><input type="radio" value="A" name="answer_14" id="" required>A. Yen</label><br>
    <label><input type="radio" value="B" name="answer_14" id="" required>B. Dollar</label><br>
    <label><input type="radio" value="C" name="answer_14" id="" required>C. Euro</label><br>
    <label><input type="radio" value="D" name="answer_14" id="" required>D. Peso</label>
    </div>
    
    <div class="con2">
    <h2>15. What is the largest continent by land area?</h2>
    <label><input type="radio" value="A" name="answer_15" id="" required>A. North America</label><br>
    <label><input type="radio" value="B" name="answer_15" id="" required>B. Europe</label><br>
    <label><input type="radio" value="C" name="answer_15" id="" required>C. Asia</label><br>
    <label><input type="radio" value="D" name="answer_15" id="" required>D. Africa</label>
    </div>
    
    <div class="con2">
    <h2>16. Which gas do planst absorb from the atmosphere during photosynthesis?</h2>
    <label><input type="radio" value="A" name="answer_16" id="" required>A. Carbon dioxide</label><br>
    <label><input type="radio" value="B" name="answer_16" id="" required>B. Oxygen</label><br>
    <label><input type="radio" value="C" name="answer_16" id="" required>C. Nitrogen</label><br>
    <label><input type="radio" value="D" name="answer_16" id="" required>D. Hydrogen</label>
    </div>
    
   

    <div class="con2">
    <h2>17. Who is the current President of the United States?</h2>
    <label><input type="radio" value="A" name="answer_17" id="" required>A. George Washington</label><br>
    <label><input type="radio" value="B" name="answer_17" id="" required>B. Abraham lincoln</label><br>
    <label><input type="radio" value="C" name="answer_17" id="" required>C. Joe Biden</label><br>
    <label><input type="radio" value="D" name="answer_17" id="" required>D. Thomas Jefferson</label>
    </div>
    
    <div class="con2">
    <h2>18. What is the symbol for the element soduim on the periodic table?</h2>
    <label><input type="radio" value="A" name="answer_18" id="" required>A. So</label><br>
    <label><input type="radio" value="B" name="answer_18" id="" required>B. Sd</label><br>
    <label><input type="radio" value="C" name="answer_18" id="" required>C. Si</label><br>
    <label><input type="radio" value="D" name="answer_18" id="" required>D. Na</label>
    </div>
    
    <div class="con2">
    <h2>19. Who wrote the famous novel "1984"?</h2>
    <label><input type="radio" value="A" name="answer_19" id="" required>A. George Orwell</label><br>
    <label><input type="radio" value="B" name="answer_19" id="" required>B. Aldous Huxely</label><br>
    <label><input type="radio" value="C" name="answer_19" id="" required>C. J.R.R. Tolkien</label><br>
    <label><input type="radio" value="D" name="answer_19" id="" required>D. Ray Bradbury</label>
    </div>

    <div class="con2">
    <h2>20. What is the largest planet in our solar system?</h2>
    <label><input type="radio" value="A" name="answer_20" id="" required>A. Earth</label><br>
    <label><input type="radio" value="B" name="answer_20" id="" required>B. Venus</label><br>
    <label><input type="radio" value="C" name="answer_20" id="" required>C. Jupiter</label><br>
    <label><input type="radio" value="D" name="answer_20" id="" required>D. Saturn</label>
    </div>

   
    
    <div class="con2">
    <h2>21.Which gas is responsible for the green color plants?</h2>
    <label><input type="radio" value="A" name="answer_21" id="" required>A. Oxygen</label><br>
    <label><input type="radio" value="B" name="answer_21" id="" required>B. Carbon dioxide</label><br>
    <label><input type="radio" value="C" name="answer_21" id="" required>C. Chlorophyll</label><br>
    <label><input type="radio" value="D" name="answer_21" id="" required>D. Nitrogen</label>
    </div>
    
    <div class="con2">
    <h2>22. Who is the known as the "Father of Modern Physics?</h2>
    <label><input type="radio" value="A" name="answer_22" id="" required>A. Isaac Newton</label><br>
    <label><input type="radio" value="B" name="answer_22" id="" required>B. Albert Einstein</label><br>
    <label><input type="radio" value="C" name="answer_22" id="" required>C. Galileo Galilei</label><br>
    <label><input type="radio" value="D" name="answer_22" id="" required>D. Nikola Tesla</label>
    </div>
    
    <div class="con2">
    <h2>23. What is the largest ocean in the world?</h2>
    <label><input type="radio" value="A" name="answer_23" id="" required>A. Atlantic Ocean</label><br>
    <label><input type="radio" value="B" name="answer_23" id="" required>B. Indian Ocean</label><br>
    <label><input type="radio" value="C" name="answer_23" id="" required>C. Pacific Ocean</label><br>
    <label><input type="radio" value="D" name="answer_23" id="" required>D. Artic Ocean</label>
    </div>
    
    <div class="con2">    
    <h2>24. Which country is known as the Land of Rising Sun?</h2>
    <label><input type="radio" value="A" name="answer_24" id="" required>A. China</label><br>
    <label><input type="radio" value="B" name="answer_24" id="" required>B. South Korea</label><br>
    <label><input type="radio" value="C" name="answer_24" id="" required>C. Japan</label><br>
    <label><input type="radio" value="D" name="answer_24" id="" required>D. Thailand</label>
    </div>
    
    <div class="con2">
    <h2>25. Who Wrote the famous play "Hamlet"?</h2>
    <label><input type="radio" value="A" name="answer_25" id="" required>A. Charles Dickens</label><br>
    <label><input type="radio" value="B" name="answer_25" id="" required>B. William Shakespeare</label><br>
    <label><input type="radio" value="C" name="answer_25" id="" required>C. Jane Austen</label><br>
    <label><input type="radio" value="D" name="answer_25" id="" required>D. Mark Twain</label>
    </div>

    </label>




    <div>
    <input type="submit" name="submit" value="Submit"class="btn">
    <div>


</form>

<br>
</body>
</html>